def car_data(num_car,date,pd):
    if num_car == 27:
        if date == '0901':
            car_data0 = pd.read_excel('DN210901-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0902':
            car_data0 = pd.read_excel('DN210902-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0903':
            car_data0 = pd.read_excel('DN210903-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0906':
            car_data0 = pd.read_excel('DN210906-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0907':
            car_data0 = pd.read_excel('DN210907-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0908':
            car_data0 = pd.read_excel('DN210908-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0909':
            car_data0 = pd.read_excel('DN210909-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0910':
            car_data0 = pd.read_excel('DN210910-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0913':
            car_data0 = pd.read_excel('DN210913-000000-CN2127.xlsx', engine='openpyxl')
        elif date == '0929':
            car_data0 = pd.read_excel('(210929)_2127.xlsx', engine='openpyxl')
        elif date == '0930':
            car_data0 = pd.read_excel('(210930)_2127.xlsx', engine='openpyxl')
        elif date == '1001':
            car_data0 = pd.read_excel('(211001)_2127.xlsx', engine='openpyxl')
        elif date == '1002':
            car_data0 = pd.read_excel('(211002)_2127.xlsx', engine='openpyxl')
        elif date == '1005':
            car_data0 = pd.read_excel('(211005)_2127.xlsx', engine='openpyxl')
        elif date == '1006':
            car_data0 = pd.read_excel('(211006)_2127.xlsx', engine='openpyxl')
        elif date == '1007':
            car_data0 = pd.read_excel('(211007)_2127.xlsx', engine='openpyxl')
        elif date == '1008':
            car_data0 = pd.read_excel('(211008)_2127.xlsx', engine='openpyxl')
        elif date == '1009':
            car_data0 = pd.read_excel('(211009)_2127.xlsx', engine='openpyxl')
        elif date == '1010':
            car_data0 = pd.read_excel('(211010)_2127.xlsx', engine='openpyxl')
        elif date == '1011':
            car_data0 = pd.read_excel('(211011)_2127.xlsx', engine='openpyxl')
        elif date == '1012':
            car_data0 = pd.read_excel('(211012)_2127.xlsx', engine='openpyxl')
        elif date == '1013':
            car_data0 = pd.read_excel('(211013)_2127.xlsx', engine='openpyxl')
        elif date == '1014':
            car_data0 = pd.read_excel('(211014)_2127.xlsx', engine='openpyxl')
        elif date == '1015':
            car_data0 = pd.read_excel('(211015)_2127.xlsx', engine='openpyxl')
        elif date == '1016':
            car_data0 = pd.read_excel('(211016)_2127.xlsx', engine='openpyxl')
        elif date == '1017':
            car_data0 = pd.read_excel('(211017)_2127.xlsx', engine='openpyxl')
        elif date == '1018':
            car_data0 = pd.read_excel('(211018)_2127.xlsx', engine='openpyxl')
        elif date == '1019':
            car_data0 = pd.read_excel('(211019)_2127.xlsx', engine='openpyxl')
    elif num_car == 33:
        if date == '0901':
            car_data0 = pd.read_excel('DN210901-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0902':
            car_data0 = pd.read_excel('DN210902-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0903':
            car_data0 = pd.read_excel('DN210903-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0906':
            car_data0 = pd.read_excel('DN210906-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0907':
            car_data0 = pd.read_excel('DN210907-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0908':
            car_data0 = pd.read_excel('DN210908-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0909':
            car_data0 = pd.read_excel('DN210909-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0910':
            car_data0 = pd.read_excel('DN210910-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0913':
            car_data0 = pd.read_excel('DN210913-000000-CN2133.xlsx', engine='openpyxl')
        elif date == '0929':
            car_data0 = pd.read_excel('(210929)_2133.xlsx', engine='openpyxl')
        elif date == '0930':
            car_data0 = pd.read_excel('(210930)_2133.xlsx', engine='openpyxl')
        elif date == '1001':
            car_data0 = pd.read_excel('(211001)_2133.xlsx', engine='openpyxl')
        elif date == '1002':
            car_data0 = pd.read_excel('(211002)_2133.xlsx', engine='openpyxl')
        elif date == '1005':
            car_data0 = pd.read_excel('(211005)_2133.xlsx', engine='openpyxl')
        elif date == '1006':
            car_data0 = pd.read_excel('(211006)_2133.xlsx', engine='openpyxl')
        elif date == '1007':
            car_data0 = pd.read_excel('(211007)_2133.xlsx', engine='openpyxl')
        elif date == '1008':
            car_data0 = pd.read_excel('(211008)_2133.xlsx', engine='openpyxl')
        elif date == '1009':
            car_data0 = pd.read_excel('(211009)_2133.xlsx', engine='openpyxl')
        elif date == '1010':
            car_data0 = pd.read_excel('(211010)_2133.xlsx', engine='openpyxl')
        elif date == '1011':
            car_data0 = pd.read_excel('(211011)_2133.xlsx', engine='openpyxl')
        elif date == '1012':
            car_data0 = pd.read_excel('(211012)_2133.xlsx', engine='openpyxl')
        elif date == '1013':
            car_data0 = pd.read_excel('(211013)_2133.xlsx', engine='openpyxl')
        elif date == '1014':
            car_data0 = pd.read_excel('(211014)_2133.xlsx', engine='openpyxl')
        elif date == '1015':
            car_data0 = pd.read_excel('(211015)_2133.xlsx', engine='openpyxl')
        elif date == '1016':
            car_data0 = pd.read_excel('(211016)_2133.xlsx', engine='openpyxl')
        elif date == '1017':
            car_data0 = pd.read_excel('(211017)_2133.xlsx', engine='openpyxl')
        elif date == '1018':
            car_data0 = pd.read_excel('(211018)_2133.xlsx', engine='openpyxl')
        elif date == '1019':
            car_data0 = pd.read_excel('(211019)_2133.xlsx', engine='openpyxl')

    return car_data0

def terminal_data(num_car,date,pd):
    if num_car == 27:
        if date == '0901':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0902':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0903':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0906':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0907':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0908':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0909':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0910':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0913':
            terminal_data0 = pd.read_excel('227_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0929':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0930':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1001':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1002':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1005':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1006':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1007':
            terminal_data0 = pd.read_excel('227_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1008':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1012':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1013':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1014':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1015':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1016':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1018':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1019':
            terminal_data0 = pd.read_excel('227_211007_211019.xlsx', sheet_name=date, engine='openpyxl')
    elif num_car == 33:
        if date == '0901':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0902':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0903':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0906':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0907':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0908':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0909':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0910':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0913':
            terminal_data0 = pd.read_excel('233_210901_210914.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0929':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '0930':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1001':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1002':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1005':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1006':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1007':
            terminal_data0 = pd.read_excel('233_210929_211007.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1008':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1012':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1013':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1014':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1015':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1016':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')
        elif date == '1018':
            terminal_data0 = pd.read_excel('233_211007_211018.xlsx', sheet_name=date, engine='openpyxl')

    return terminal_data0