import numpy as np
import pandas as pd
import time
import math
from collections import Counter

start = time.time()

num_station = 27

block_length = 5
max_block_length = 1974
num_block = math.ceil(max_block_length/block_length)

block = np.array([])

for n in range(0,num_block+1):
    block = np.append(block, np.array([block_length*n]))

#print(block)

BS_1_1 = np.loadtxt('BS_1_1_re.txt', delimiter=',', dtype='int')
BS_1_2 = np.loadtxt('BS_1_2_re.txt', delimiter=',', dtype='int')
BS_2_1 = np.loadtxt('BS_2_1_re.txt', delimiter=',', dtype='int')
BS_2_2 = np.loadtxt('BS_2_2_re.txt', delimiter=',', dtype='int')

BS_1_1 = np.array([BS_1_1])
BS_1_2 = np.array([BS_1_2])
BS_2_1 = np.array([BS_2_1])
BS_2_2 = np.array([BS_2_2])

RSRP_1_1 = np.loadtxt('RSRP_1_1_re.txt', delimiter=',', dtype='int')
RSRP_1_2 = np.loadtxt('RSRP_1_2_re.txt', delimiter=',', dtype='int')
RSRP_2_1 = np.loadtxt('RSRP_2_1_re.txt', delimiter=',', dtype='int')
RSRP_2_2 = np.loadtxt('RSRP_2_2_re.txt', delimiter=',', dtype='int')

RSRP_1_1 = np.array([RSRP_1_1])
RSRP_1_2 = np.array([RSRP_1_2])
RSRP_2_1 = np.array([RSRP_2_1])
RSRP_2_2 = np.array([RSRP_2_2])

RSSI_1_1 = np.loadtxt('RSSI_1_1_re.txt', delimiter=',', dtype='int')
RSSI_1_2 = np.loadtxt('RSSI_1_2_re.txt', delimiter=',', dtype='int')
RSSI_2_1 = np.loadtxt('RSSI_2_1_re.txt', delimiter=',', dtype='int')
RSSI_2_2 = np.loadtxt('RSSI_2_2_re.txt', delimiter=',', dtype='int')

RSSI_1_1 = np.array([RSSI_1_1])
RSSI_1_2 = np.array([RSSI_1_2])
RSSI_2_1 = np.array([RSSI_2_1])
RSSI_2_2 = np.array([RSSI_2_2])

RSRQ_1_1 = np.loadtxt('RSRQ_1_1_re.txt', delimiter=',', dtype='int')
RSRQ_1_2 = np.loadtxt('RSRQ_1_2_re.txt', delimiter=',', dtype='int')
RSRQ_2_1 = np.loadtxt('RSRQ_2_1_re.txt', delimiter=',', dtype='int')
RSRQ_2_2 = np.loadtxt('RSRQ_2_2_re.txt', delimiter=',', dtype='int')

RSRQ_1_1 = np.array([RSRQ_1_1])
RSRQ_1_2 = np.array([RSRQ_1_2])
RSRQ_2_1 = np.array([RSRQ_2_1])
RSRQ_2_2 = np.array([RSRQ_2_2])

next_station_1_1 = np.loadtxt('next_station_1_1_re.txt', delimiter=',', dtype='int')
next_station_1_2 = np.loadtxt('next_station_1_2_re.txt', delimiter=',', dtype='int')
next_station_2_1 = np.loadtxt('next_station_2_1_re.txt', delimiter=',', dtype='int')
next_station_2_2 = np.loadtxt('next_station_2_2_re.txt', delimiter=',', dtype='int')

next_station_1_1 = np.array([next_station_1_1])
next_station_1_2 = np.array([next_station_1_2])
next_station_2_1 = np.array([next_station_2_1])
next_station_2_2 = np.array([next_station_2_2])

dist_1_1 = np.loadtxt('dist_1_1_re.txt', delimiter=',', dtype='int')
dist_1_2 = np.loadtxt('dist_1_2_re.txt', delimiter=',', dtype='int')
dist_2_1 = np.loadtxt('dist_2_1_re.txt', delimiter=',', dtype='int')
dist_2_2 = np.loadtxt('dist_2_2_re.txt', delimiter=',', dtype='int')

dist_1_1 = np.array([dist_1_1])
dist_1_2 = np.array([dist_1_2])
dist_2_1 = np.array([dist_2_1])
dist_2_2 = np.array([dist_2_2])

#print(dist_1_1.max())
#print(dist_1_2.max())
#print(dist_2_1.max())
#print(dist_2_2.max())

#print(type(dist_1_1))

mean_RSRP_1_1 = np.array([])
mean_RSRP_1_2 = np.array([])
mean_RSRP_2_1 = np.array([])
mean_RSRP_2_2 = np.array([])

mean_RSRP_1_1_sec = np.array([])
mean_RSRP_1_2_sec = np.array([])
mean_RSRP_2_1_sec = np.array([])
mean_RSRP_2_2_sec = np.array([])

mean_RSRP_1_1_array = np.array([])
mean_RSRP_1_2_array = np.array([])
mean_RSRP_2_1_array = np.array([])
mean_RSRP_2_2_array = np.array([])

mean_RSSI_1_1 = np.array([])
mean_RSSI_1_2 = np.array([])
mean_RSSI_2_1 = np.array([])
mean_RSSI_2_2 = np.array([])

mean_RSSI_1_1_sec = np.array([])
mean_RSSI_1_2_sec = np.array([])
mean_RSSI_2_1_sec = np.array([])
mean_RSSI_2_2_sec = np.array([])

mean_RSSI_1_1_array = np.array([])
mean_RSSI_1_2_array = np.array([])
mean_RSSI_2_1_array = np.array([])
mean_RSSI_2_2_array = np.array([])

mean_RSRQ_1_1 = np.array([])
mean_RSRQ_1_2 = np.array([])
mean_RSRQ_2_1 = np.array([])
mean_RSRQ_2_2 = np.array([])

mean_RSRQ_1_1_sec = np.array([])
mean_RSRQ_1_2_sec = np.array([])
mean_RSRQ_2_1_sec = np.array([])
mean_RSRQ_2_2_sec = np.array([])

mean_RSRQ_1_1_array = np.array([])
mean_RSRQ_1_2_array = np.array([])
mean_RSRQ_2_1_array = np.array([])
mean_RSRQ_2_2_array = np.array([])

count_RSRP_1_1 = np.array([])
count_RSRP_1_2 = np.array([])
count_RSRP_2_1 = np.array([])
count_RSRP_2_2 = np.array([])

count_RSRP_1_1_sec = np.array([])
count_RSRP_1_2_sec = np.array([])
count_RSRP_2_1_sec = np.array([])
count_RSRP_2_2_sec = np.array([])

count_RSSI_1_1 = np.array([])
count_RSSI_1_2 = np.array([])
count_RSSI_2_1 = np.array([])
count_RSSI_2_2 = np.array([])

count_RSSI_1_1_sec = np.array([])
count_RSSI_1_2_sec = np.array([])
count_RSSI_2_1_sec = np.array([])
count_RSSI_2_2_sec = np.array([])

count_RSRQ_1_1 = np.array([])
count_RSRQ_1_2 = np.array([])
count_RSRQ_2_1 = np.array([])
count_RSRQ_2_2 = np.array([])

count_RSRQ_1_1_sec = np.array([])
count_RSRQ_1_2_sec = np.array([])
count_RSRQ_2_1_sec = np.array([])
count_RSRQ_2_2_sec = np.array([])

mean_index_1_1 = np.array([])
mean_index_1_2 = np.array([])
mean_index_2_1 = np.array([])
mean_index_2_2 = np.array([])

p_BS_1_1 = np.array([])
p_BS_1_2 = np.array([])
p_BS_2_1 = np.array([])
p_BS_2_2 = np.array([])

R_BS_1_1 = np.array([])
R_BS_1_2 = np.array([])
R_BS_2_1 = np.array([])
R_BS_2_2 = np.array([])

R_BS_1_1_sec = np.array([])
R_BS_1_2_sec = np.array([])
R_BS_2_1_sec = np.array([])
R_BS_2_2_sec = np.array([])

final_RSRP_1_1 = np.array([])
final_RSRP_1_2 = np.array([])
final_RSRP_2_1 = np.array([])
final_RSRP_2_2 = np.array([])

final_RSSI_1_1 = np.array([])
final_RSSI_1_2 = np.array([])
final_RSSI_2_1 = np.array([])
final_RSSI_2_2 = np.array([])

final_RSRQ_1_1 = np.array([])
final_RSRQ_1_2 = np.array([])
final_RSRQ_2_1 = np.array([])
final_RSRQ_2_2 = np.array([])

for i in range(0,num_station):
    index_1_1 = np.where(next_station_1_1 == i)
    index_1_2 = np.where(next_station_1_2 == i)
    index_2_1 = np.where(next_station_2_1 == i)
    index_2_2 = np.where(next_station_2_2 == i)

    temp_dist_1_1 = dist_1_1[index_1_1]
    temp_dist_1_2 = dist_1_2[index_1_2]
    temp_dist_2_1 = dist_2_1[index_2_1]
    temp_dist_2_2 = dist_2_2[index_2_2]

    temp_BS_1_1 = BS_1_1[index_1_1]
    temp_BS_1_2 = BS_1_2[index_1_2]
    temp_BS_2_1 = BS_2_1[index_2_1]
    temp_BS_2_2 = BS_2_2[index_2_2]

    p_BS_1_1 = np.append(p_BS_1_1, np.array([temp_BS_1_1]))
    p_BS_1_2 = np.append(p_BS_1_2, np.array([temp_BS_1_2]))
    p_BS_2_1 = np.append(p_BS_2_1, np.array([temp_BS_2_1]))
    p_BS_2_2 = np.append(p_BS_2_2, np.array([temp_BS_2_2]))

    temp_RSRP_1_1 = RSRP_1_1[index_1_1]
    temp_RSRP_1_2 = RSRP_1_2[index_1_2]
    temp_RSRP_2_1 = RSRP_2_1[index_2_1]
    temp_RSRP_2_2 = RSRP_2_2[index_2_2]

    temp_RSSI_1_1 = RSSI_1_1[index_1_1]
    temp_RSSI_1_2 = RSSI_1_2[index_1_2]
    temp_RSSI_2_1 = RSSI_2_1[index_2_1]
    temp_RSSI_2_2 = RSSI_2_2[index_2_2]

    temp_RSRQ_1_1 = RSRQ_1_1[index_1_1]
    temp_RSRQ_1_2 = RSRQ_1_2[index_1_2]
    temp_RSRQ_2_1 = RSRQ_2_1[index_2_1]
    temp_RSRQ_2_2 = RSRQ_2_2[index_2_2]

    for j in range(0,num_block):
        temp_index_1_1 = np.where((temp_dist_1_1 >= block[j]) & (temp_dist_1_1 < block[j + 1]))
        temp_index_1_2 = np.where((temp_dist_1_2 >= block[j]) & (temp_dist_1_2 < block[j + 1]))
        temp_index_2_1 = np.where((temp_dist_2_1 >= block[j]) & (temp_dist_2_1 < block[j + 1]))
        temp_index_2_2 = np.where((temp_dist_2_2 >= block[j]) & (temp_dist_2_2 < block[j + 1]))

        t_BS_1_1 = temp_BS_1_1[temp_index_1_1]
        cnt_BS_1_1 = Counter(t_BS_1_1)
        if not list(cnt_BS_1_1):
            #R_BS_1_1 = np.append(R_BS_1_1, [np.nan, np.nan])
            R_BS_1_1 = np.append(R_BS_1_1, np.nan)
        else:
            #if len(cnt_BS_1_1.most_common()) >= 2:
            #    tt_BS_1_1 = np.array([cnt_BS_1_1.most_common(2)[0][0], cnt_BS_1_1.most_common(2)[1][0]])
            #elif len(cnt_BS_1_1.most_common()) == 1:
            #    tt_BS_1_1 = np.array([cnt_BS_1_1.most_common(1)[0][0], cnt_BS_1_1.most_common(1)[0][0]])
            #R_BS_1_1 = np.append(R_BS_1_1, tt_BS_1_1)
            R_BS_1_1 = np.append(R_BS_1_1, np.array([cnt_BS_1_1.most_common(1)[0][0]]))
        #print('R_BS_1_1 = ', R_BS_1_1)
        t_BS_1_2 = temp_BS_1_2[temp_index_1_2]
        cnt_BS_1_2 = Counter(t_BS_1_2)
        if not list(cnt_BS_1_2):
            #R_BS_1_2 = np.append(R_BS_1_2, [np.nan, np.nan])
            R_BS_1_2 = np.append(R_BS_1_2, np.nan)
        else:
            #if len(cnt_BS_1_2.most_common()) >= 2:
            #    tt_BS_1_2 = np.array([cnt_BS_1_2.most_common(2)[0][0], cnt_BS_1_2.most_common(2)[1][0]])
            #elif len(cnt_BS_1_2.most_common()) == 1:
            #    tt_BS_1_2 = np.array([cnt_BS_1_2.most_common(1)[0][0], cnt_BS_1_2.most_common(1)[0][0]])
            #R_BS_1_2 = np.append(R_BS_1_2, tt_BS_1_2)
            R_BS_1_2 = np.append(R_BS_1_2, np.array([cnt_BS_1_2.most_common(1)[0][0]]))
        t_BS_2_1 = temp_BS_2_1[temp_index_2_1]
        cnt_BS_2_1 = Counter(t_BS_2_1)
        if not list(cnt_BS_2_1):
            #R_BS_2_1 = np.append(R_BS_2_1, [np.nan, np.nan])
            R_BS_2_1 = np.append(R_BS_2_1, np.nan)
        else:
            #if len(cnt_BS_2_1.most_common()) >= 2:
            #    tt_BS_2_1 = np.array([cnt_BS_2_1.most_common(2)[0][0], cnt_BS_2_1.most_common(2)[1][0]])
            #elif len(cnt_BS_2_1.most_common()) == 1:
            #    tt_BS_2_1 = np.array([cnt_BS_2_1.most_common(1)[0][0], cnt_BS_2_1.most_common(1)[0][0]])
            #R_BS_2_1 = np.append(R_BS_2_1, tt_BS_2_1)
            R_BS_2_1 = np.append(R_BS_2_1, np.array([cnt_BS_2_1.most_common(1)[0][0]]))
        t_BS_2_2 = temp_BS_2_2[temp_index_2_2]
        cnt_BS_2_2 = Counter(t_BS_2_2)
        if not list(cnt_BS_2_2):
            #R_BS_2_2 = np.append(R_BS_2_2, [np.nan, np.nan])
            R_BS_2_2 = np.append(R_BS_2_2, np.nan)
        else:
            #if len(cnt_BS_2_2.most_common()) >= 2:
            #    tt_BS_2_2 = np.array([cnt_BS_2_2.most_common(2)[0][0], cnt_BS_2_2.most_common(2)[1][0]])
            #elif len(cnt_BS_2_2.most_common()) == 1:
            #    tt_BS_2_2 = np.array([cnt_BS_2_2.most_common(1)[0][0], cnt_BS_2_2.most_common(1)[0][0]])
            #R_BS_2_2 = np.append(R_BS_2_2, tt_BS_2_2)
            R_BS_2_2 = np.append(R_BS_2_2, np.array([cnt_BS_2_2.most_common(1)[0][0]]))
        #print(cnt_BS_1_1.most_common(1))
        #print(cnt_BS_1_1)

        #print('tt_BS_1_1[0] = ', tt_BS_1_1)
        #print('cnt_BS_1_1 = ', cnt_BS_1_1)
        #t_index_1_1 = np.where(t_BS_1_1 == tt_BS_1_1[0])
        t_RSRP_1_1 = temp_RSRP_1_1[temp_index_1_1]
        #t_index_1_1_sec = np.where(t_BS_1_1 == tt_BS_1_1[1])
        #t_RSRP_1_1_sec = temp_RSRP_1_1[t_index_1_1_sec]
        mean_RSRP_1_1 = np.append(mean_RSRP_1_1, np.array([t_RSRP_1_1.mean()]))
        #mean_RSRP_1_1_sec = np.append(mean_RSRP_1_1_sec, np.array([t_RSRP_1_1_sec.mean()]))
        #mean_RSRP_1_1_array = np.append(mean_RSRP_1_1_array, np.array([t_RSRP_1_1.mean(), t_RSRP_1_1_sec.mean()]))
        #t_RSRP_1_1 = temp_RSRP_1_1[temp_index_1_1]
        #mean_RSRP_1_1 = np.append(mean_RSRP_1_1, np.array([t_RSRP_1_1.mean()]))
        cnt_RSRP_1_1 = Counter(temp_RSRP_1_1[temp_index_1_1])
        if not list(cnt_RSRP_1_1):
            #count_RSRP_1_1 = np.append(count_RSRP_1_1, [np.nan, np.nan])
            count_RSRP_1_1 = np.append(count_RSRP_1_1, np.nan)
        else:
            #if len(cnt_RSRP_1_1.most_common()) >= 2:
            #    tt_count_RSRP_1_1 = np.array([cnt_RSRP_1_1.most_common(2)[0][0], cnt_RSRP_1_1.most_common(2)[1][0]])
            #elif len(cnt_RSRP_1_1.most_common()) == 1:
            #    tt_count_RSRP_1_1 = np.array([cnt_RSRP_1_1.most_common(1)[0][0], cnt_RSRP_1_1.most_common(1)[0][0]])
            #count_RSRP_1_1 = np.append(count_RSRP_1_1, tt_count_RSRP_1_1)
            count_RSRP_1_1 = np.append(count_RSRP_1_1, np.array([cnt_RSRP_1_1.most_common(1)[0][0]]))

        t_RSRP_1_2 = temp_RSRP_1_2[temp_index_1_2]
        #mean_RSRP_1_2 = np.append(mean_RSRP_1_2, np.array([t_RSRP_1_2.mean()]))
        #cnt_RSRP_1_2 = Counter(t_RSRP_1_2)
        #t_index_1_2 = np.where(t_BS_1_2 == tt_BS_1_2[0])
        #t_RSRP_1_2 = temp_RSRP_1_2[t_index_1_2]
        #t_index_1_2_sec = np.where(t_BS_1_2 == tt_BS_1_2[1])
        #t_RSRP_1_2_sec = temp_RSRP_1_2[t_index_1_2_sec]
        mean_RSRP_1_2 = np.append(mean_RSRP_1_2, np.array([t_RSRP_1_2.mean()]))
        #mean_RSRP_1_2_sec = np.append(mean_RSRP_1_2_sec, np.array([t_RSRP_1_2_sec.mean()]))
        #mean_RSRP_1_2_array = np.append(mean_RSRP_1_2_array, np.array([t_RSRP_1_2.mean(), t_RSRP_1_2_sec.mean()]))
        cnt_RSRP_1_2 = Counter(temp_RSRP_1_2[temp_index_1_2])
        if not list(cnt_RSRP_1_2):
            #count_RSRP_1_2 = np.append(count_RSRP_1_2, [np.nan, np.nan])
            count_RSRP_1_2 = np.append(count_RSRP_1_2, np.nan)
        else:
            #if len(cnt_RSRP_1_2.most_common()) >= 2:
            #    tt_count_RSRP_1_2 = np.array([cnt_RSRP_1_2.most_common(2)[0][0], cnt_RSRP_1_2.most_common(2)[1][0]])
            #elif len(cnt_RSRP_1_2.most_common()) == 1:
            #    tt_count_RSRP_1_2 = np.array([cnt_RSRP_1_2.most_common(1)[0][0], cnt_RSRP_1_2.most_common(1)[0][0]])
            #count_RSRP_1_2 = np.append(count_RSRP_1_2, tt_count_RSRP_1_2)
            count_RSRP_1_2 = np.append(count_RSRP_1_2, np.array([cnt_RSRP_1_2.most_common(1)[0][0]]))
        t_RSRP_2_1 = temp_RSRP_2_1[temp_index_2_1]
        #mean_RSRP_2_1 = np.append(mean_RSRP_2_1, np.array([t_RSRP_2_1.mean()]))
        #cnt_RSRP_2_1 = Counter(t_RSRP_2_1)
        #t_index_2_1 = np.where(t_BS_2_1 == tt_BS_2_1[0])
        #t_RSRP_2_1 = temp_RSRP_2_1[t_index_2_1]
        #t_index_2_1_sec = np.where(t_BS_2_1 == tt_BS_2_1[1])
        #t_RSRP_2_1_sec = temp_RSRP_2_1[t_index_2_1_sec]
        mean_RSRP_2_1 = np.append(mean_RSRP_2_1, np.array([t_RSRP_2_1.mean()]))
        #mean_RSRP_2_1_sec = np.append(mean_RSRP_2_1_sec, np.array([t_RSRP_2_1_sec.mean()]))
        #mean_RSRP_2_1_array = np.append(mean_RSRP_2_1_array, np.array([t_RSRP_2_1.mean(), t_RSRP_2_1_sec.mean()]))
        cnt_RSRP_2_1 = Counter(temp_RSRP_2_1[temp_index_2_1])
        if not list(cnt_RSRP_2_1):
            #count_RSRP_2_1 = np.append(count_RSRP_2_1, [np.nan, np.nan])
            count_RSRP_2_1 = np.append(count_RSRP_2_1, np.nan)
        else:
            #if len(cnt_RSRP_2_1.most_common()) >= 2:
            #    tt_count_RSRP_2_1 = np.array([cnt_RSRP_2_1.most_common(2)[0][0], cnt_RSRP_2_1.most_common(2)[1][0]])
            #elif len(cnt_RSRP_2_1.most_common()) == 1:
            #    tt_count_RSRP_2_1 = np.array([cnt_RSRP_2_1.most_common(1)[0][0], cnt_RSRP_2_1.most_common(1)[0][0]])
            #count_RSRP_2_1 = np.append(count_RSRP_2_1, tt_count_RSRP_2_1)
            count_RSRP_2_1 = np.append(count_RSRP_2_1, np.array([cnt_RSRP_2_1.most_common(1)[0][0]]))
        t_RSRP_2_2 = temp_RSRP_2_2[temp_index_2_2]
        #mean_RSRP_2_2 = np.append(mean_RSRP_2_2, np.array([t_RSRP_2_2.mean()]))
        #cnt_RSRP_2_2 = Counter(t_RSRP_2_2)
        #t_index_2_2 = np.where(t_BS_2_2 == tt_BS_2_2[0])
        #t_RSRP_2_2 = temp_RSRP_2_2[t_index_2_2]
        #t_index_2_2_sec = np.where(t_BS_2_2 == tt_BS_2_2[1])
        #t_RSRP_2_2_sec = temp_RSRP_2_2[t_index_2_2_sec]
        mean_RSRP_2_2 = np.append(mean_RSRP_2_2, np.array([t_RSRP_2_2.mean()]))
        #mean_RSRP_2_2_sec = np.append(mean_RSRP_2_2_sec, np.array([t_RSRP_2_2_sec.mean()]))
        #mean_RSRP_2_2_array = np.append(mean_RSRP_2_2_array, np.array([t_RSRP_2_2.mean(), t_RSRP_2_2_sec.mean()]))
        cnt_RSRP_2_2 = Counter(temp_RSRP_2_2[temp_index_2_2])
        if not list(cnt_RSRP_2_2):
            #count_RSRP_2_2 = np.append(count_RSRP_2_2, [np.nan, np.nan])
            count_RSRP_2_2 = np.append(count_RSRP_2_2, np.nan)
        else:
            #if len(cnt_RSRP_2_2.most_common()) >= 2:
            #    tt_count_RSRP_2_2 = np.array([cnt_RSRP_2_2.most_common(2)[0][0], cnt_RSRP_2_2.most_common(2)[1][0]])
            #elif len(cnt_RSRP_2_2.most_common()) == 1:
            #    tt_count_RSRP_2_2 = np.array([cnt_RSRP_2_2.most_common(1)[0][0], cnt_RSRP_2_2.most_common(1)[0][0]])
            #count_RSRP_2_2 = np.append(count_RSRP_2_2, tt_count_RSRP_2_2)
            count_RSRP_2_2 = np.append(count_RSRP_2_2, np.array([cnt_RSRP_2_2.most_common(1)[0][0]]))
        #print(mean_RSRP_1_1)

        #print(mean_RSRP_1_1)

        t_RSSI_1_1 = temp_RSSI_1_1[temp_index_1_1]
        #mean_RSSI_1_1 = np.append(mean_RSSI_1_1, np.array([t_RSSI_1_1.mean()]))
        #cnt_RSSI_1_1 = Counter(t_RSSI_1_1)
        #t_index_1_1 = np.where(t_BS_1_1 == tt_BS_1_1[0])
        #t_RSSI_1_1 = temp_RSSI_1_1[t_index_1_1]
        #t_index_1_1_sec = np.where(t_BS_1_1 == tt_BS_1_1[1])
        #t_RSSI_1_1_sec = temp_RSSI_1_1[t_index_1_1_sec]
        mean_RSSI_1_1 = np.append(mean_RSSI_1_1, np.array([t_RSSI_1_1.mean()]))
        #mean_RSSI_1_1_sec = np.append(mean_RSSI_1_1_sec, np.array([t_RSSI_1_1_sec.mean()]))
        #mean_RSSI_1_1_array = np.append(mean_RSSI_1_1_array, np.array([t_RSSI_1_1.mean(), t_RSSI_1_1_sec.mean()]))
        cnt_RSSI_1_1 = Counter(temp_RSSI_1_1[temp_index_1_1])
        if not list(cnt_RSSI_1_1):
            #count_RSSI_1_1 = np.append(count_RSSI_1_1, [np.nan, np.nan])
            count_RSSI_1_1 = np.append(count_RSSI_1_1, np.nan)
        else:
            #if len(cnt_RSSI_1_1.most_common()) >= 2:
            #    tt_count_RSSI_1_1 = np.array([cnt_RSSI_1_1.most_common(2)[0][0], cnt_RSSI_1_1.most_common(2)[1][0]])
            #elif len(cnt_RSSI_1_1.most_common()) == 1:
            #    tt_count_RSSI_1_1 = np.array([cnt_RSSI_1_1.most_common(1)[0][0], cnt_RSSI_1_1.most_common(1)[0][0]])
            #count_RSSI_1_1 = np.append(count_RSSI_1_1, tt_count_RSSI_1_1)
            count_RSSI_1_1 = np.append(count_RSSI_1_1, np.array([cnt_RSSI_1_1.most_common(1)[0][0]]))
        t_RSSI_1_2 = temp_RSSI_1_2[temp_index_1_2]
        #mean_RSSI_1_2 = np.append(mean_RSSI_1_2, np.array([t_RSSI_1_2.mean()]))
        #cnt_RSSI_1_2 = Counter(t_RSSI_1_2)
        #t_index_1_2 = np.where(t_BS_1_2 == tt_BS_1_2[0])
        #t_RSSI_1_2 = temp_RSSI_1_2[t_index_1_2]
        #t_index_1_2_sec = np.where(t_BS_1_2 == tt_BS_1_2[1])
        #t_RSSI_1_2_sec = temp_RSSI_1_2[t_index_1_2_sec]
        mean_RSSI_1_2 = np.append(mean_RSSI_1_2, np.array([t_RSSI_1_2.mean()]))
        #mean_RSSI_1_2_sec = np.append(mean_RSSI_1_2_sec, np.array([t_RSSI_1_2_sec.mean()]))
        #mean_RSSI_1_2_array = np.append(mean_RSSI_1_2_array, np.array([t_RSSI_1_2.mean(), t_RSSI_1_2_sec.mean()]))
        cnt_RSSI_1_2 = Counter(temp_RSSI_1_2[temp_index_1_2])
        if not list(cnt_RSSI_1_2):
            #count_RSSI_1_2 = np.append(count_RSSI_1_2, [np.nan, np.nan])
            count_RSSI_1_2 = np.append(count_RSSI_1_2, np.nan)
        else:
            #if len(cnt_RSSI_1_2.most_common()) >= 2:
            #    tt_count_RSSI_1_2 = np.array([cnt_RSSI_1_2.most_common(2)[0][0], cnt_RSSI_1_2.most_common(2)[1][0]])
            #elif len(cnt_RSSI_1_2.most_common()) == 1:
            #    tt_count_RSSI_1_2 = np.array([cnt_RSSI_1_2.most_common(1)[0][0], cnt_RSSI_1_2.most_common(1)[0][0]])
            #count_RSSI_1_2 = np.append(count_RSSI_1_2, tt_count_RSSI_1_2)
            count_RSSI_1_2 = np.append(count_RSSI_1_2, np.array([cnt_RSSI_1_2.most_common(1)[0][0]]))
        t_RSSI_2_1 = temp_RSSI_2_1[temp_index_2_1]
        #mean_RSSI_2_1 = np.append(mean_RSSI_2_1, np.array([t_RSSI_2_1.mean()]))
        #cnt_RSSI_2_1 = Counter(t_RSSI_2_1)
        #t_index_2_1 = np.where(t_BS_2_1 == tt_BS_2_1[0])
        #t_RSSI_2_1 = temp_RSSI_2_1[t_index_2_1]
        #t_index_2_1_sec = np.where(t_BS_2_1 == tt_BS_2_1[1])
        #t_RSSI_2_1_sec = temp_RSSI_2_1[t_index_2_1_sec]
        mean_RSSI_2_1 = np.append(mean_RSSI_2_1, np.array([t_RSSI_2_1.mean()]))
        #mean_RSSI_2_1_sec = np.append(mean_RSSI_2_1_sec, np.array([t_RSSI_2_1_sec.mean()]))
        #mean_RSSI_2_1_array = np.append(mean_RSSI_2_1_array, np.array([t_RSSI_2_1.mean(), t_RSSI_2_1_sec.mean()]))
        cnt_RSSI_2_1 = Counter(temp_RSSI_2_1[temp_index_2_1])
        if not list(cnt_RSSI_2_1):
            #count_RSSI_2_1 = np.append(count_RSSI_2_1, [np.nan, np.nan])
            count_RSSI_2_1 = np.append(count_RSSI_2_1, np.nan)
        else:
            #if len(cnt_RSSI_2_1.most_common()) >= 2:
            #    tt_count_RSSI_2_1 = np.array([cnt_RSSI_2_1.most_common(2)[0][0], cnt_RSSI_2_1.most_common(2)[1][0]])
            #elif len(cnt_RSSI_2_1.most_common()) == 1:
            #    tt_count_RSSI_2_1 = np.array([cnt_RSSI_2_1.most_common(1)[0][0], cnt_RSSI_2_1.most_common(1)[0][0]])
            #count_RSSI_2_1 = np.append(count_RSSI_2_1, tt_count_RSSI_2_1)
            count_RSSI_2_1 = np.append(count_RSSI_2_1, np.array([cnt_RSSI_2_1.most_common(1)[0]]))
        t_RSSI_2_2 = temp_RSSI_2_2[temp_index_2_2]
        #mean_RSSI_2_2 = np.append(mean_RSSI_2_2, np.array([t_RSSI_2_2.mean()]))
        #cnt_RSSI_2_2 = Counter(t_RSSI_2_2)
        #t_index_2_2 = np.where(t_BS_2_2 == tt_BS_2_2[0])
        #t_RSSI_2_2 = temp_RSSI_2_2[t_index_2_2]
        #t_index_2_2_sec = np.where(t_BS_2_2 == tt_BS_2_2[1])
        #t_RSSI_2_2_sec = temp_RSSI_2_2[t_index_2_2_sec]
        mean_RSSI_2_2 = np.append(mean_RSSI_2_2, np.array([t_RSSI_2_2.mean()]))
        #mean_RSSI_2_2_sec = np.append(mean_RSSI_2_2_sec, np.array([t_RSSI_2_2_sec.mean()]))
        #mean_RSSI_2_2_array = np.append(mean_RSSI_2_2_array, np.array([t_RSSI_2_2.mean(), t_RSSI_2_2_sec.mean()]))
        cnt_RSSI_2_2 = Counter(temp_RSSI_2_2[temp_index_2_2])
        if not list(cnt_RSSI_2_2):
            #count_RSSI_2_2 = np.append(count_RSSI_2_2, [np.nan, np.nan])
            count_RSSI_2_2 = np.append(count_RSSI_2_2, np.nan)
        else:
            #if len(cnt_RSSI_2_2.most_common()) >= 2:
            #    tt_count_RSSI_2_2 = np.array([cnt_RSSI_2_2.most_common(2)[0][0], cnt_RSSI_2_2.most_common(2)[1][0]])
            #elif len(cnt_RSSI_2_2.most_common()) == 1:
            #    tt_count_RSSI_2_2 = np.array([cnt_RSSI_2_2.most_common(1)[0][0], cnt_RSSI_2_2.most_common(1)[0][0]])
            #count_RSSI_2_2 = np.append(count_RSSI_2_2, tt_count_RSSI_2_2)
            count_RSSI_2_2 = np.append(count_RSSI_2_2, np.array([cnt_RSSI_2_2.most_common(1)[0][0]]))

        t_RSRQ_1_1 = temp_RSRQ_1_1[temp_index_1_1]
        #mean_RSRQ_1_1 = np.append(mean_RSRQ_1_1, np.array([t_RSRQ_1_1.mean()]))
        #cnt_RSRQ_1_1 = Counter(t_RSRQ_1_1)
        #t_index_1_1 = np.where(t_BS_1_1 == tt_BS_1_1[0])
        #t_RSRQ_1_1 = temp_RSRQ_1_1[t_index_1_1]
        #t_index_1_1_sec = np.where(t_BS_1_1 == tt_BS_1_1[1])
        #t_RSRQ_1_1_sec = temp_RSRQ_1_1[t_index_1_1_sec]
        mean_RSRQ_1_1 = np.append(mean_RSRQ_1_1, np.array([t_RSRQ_1_1.mean()]))
        #mean_RSRQ_1_1_sec = np.append(mean_RSRQ_1_1_sec, np.array([t_RSRQ_1_1_sec.mean()]))
        #mean_RSRQ_1_1_array = np.append(mean_RSRQ_1_1_array, np.array([t_RSRQ_1_1.mean(), t_RSRQ_1_1_sec.mean()]))
        cnt_RSRQ_1_1 = Counter(temp_RSRQ_1_1[temp_index_1_1])
        if not list(cnt_RSRQ_1_1):
            #count_RSRQ_1_1 = np.append(count_RSRQ_1_1, [np.nan, np.nan])
            count_RSRQ_1_1 = np.append(count_RSRQ_1_1, np.nan)
        else:
            #if len(cnt_RSRQ_1_1.most_common()) >= 2:
            #    tt_count_RSRQ_1_1 = np.array([cnt_RSRQ_1_1.most_common(2)[0][0], cnt_RSRQ_1_1.most_common(2)[1][0]])
            #elif len(cnt_RSRQ_1_1.most_common()) == 1:
            #    tt_count_RSRQ_1_1 = np.array([cnt_RSRQ_1_1.most_common(1)[0][0], cnt_RSRQ_1_1.most_common(1)[0][0]])
            #count_RSRQ_1_1 = np.append(count_RSRQ_1_1, tt_count_RSRQ_1_1)
            count_RSRQ_1_1 = np.append(count_RSRQ_1_1, np.array([cnt_RSRQ_1_1.most_common(1)[0][0]]))
        t_RSRQ_1_2 = temp_RSRQ_1_2[temp_index_1_2]
        #mean_RSRQ_1_2 = np.append(mean_RSRQ_1_2, np.array([t_RSRQ_1_2.mean()]))
        #cnt_RSRQ_1_2 = Counter(t_RSRQ_1_2)
        #t_index_1_2 = np.where(t_BS_1_2 == tt_BS_1_2[0])
        #t_RSRQ_1_2 = temp_RSRQ_1_2[t_index_1_2]
        #t_index_1_2_sec = np.where(t_BS_1_2 == tt_BS_1_2[1])
        #t_RSRQ_1_2_sec = temp_RSRQ_1_2[t_index_1_2_sec]
        mean_RSRQ_1_2 = np.append(mean_RSRQ_1_2, np.array([t_RSRQ_1_2.mean()]))
        #mean_RSRQ_1_2_sec = np.append(mean_RSRQ_1_2_sec, np.array([t_RSRQ_1_2_sec.mean()]))
        #mean_RSRQ_1_2_array = np.append(mean_RSRQ_1_2_array, np.array([t_RSRQ_1_2.mean(), t_RSRQ_1_2_sec.mean()]))
        cnt_RSRQ_1_2 = Counter(temp_RSRQ_1_2[temp_index_1_2])
        if not list(cnt_RSRQ_1_2):
            #count_RSRQ_1_2 = np.append(count_RSRQ_1_2, [np.nan, np.nan])
            count_RSRQ_1_2 = np.append(count_RSRQ_1_2, np.nan)
        else:
            #if len(cnt_RSRQ_1_2.most_common()) >= 2:
            #    tt_count_RSRQ_1_2 = np.array([cnt_RSRQ_1_2.most_common(2)[0][0], cnt_RSRQ_1_2.most_common(2)[1][0]])
            #elif len(cnt_RSRQ_1_2.most_common()) == 1:
            #    tt_count_RSRQ_1_2 = np.array([cnt_RSRQ_1_2.most_common(1)[0][0], cnt_RSRQ_1_2.most_common(1)[0][0]])
            #count_RSRQ_1_2 = np.append(count_RSRQ_1_2, tt_count_RSRQ_1_2)
            count_RSRQ_1_2 = np.append(count_RSRQ_1_2, np.array([cnt_RSRQ_1_2.most_common(1)[0][0]]))
        t_RSRQ_2_1 = temp_RSRQ_2_1[temp_index_2_1]
        #mean_RSRQ_2_1 = np.append(mean_RSRQ_2_1, np.array([t_RSRQ_2_1.mean()]))
        #cnt_RSRQ_2_1 = Counter(t_RSRQ_2_1)
        #t_index_2_1 = np.where(t_BS_2_1 == tt_BS_2_1[0])
        #t_RSRQ_2_1 = temp_RSRQ_2_1[t_index_2_1]
        #t_index_2_1_sec = np.where(t_BS_2_1 == tt_BS_2_1[1])
        #t_RSRQ_2_1_sec = temp_RSRQ_2_1[t_index_2_1_sec]
        mean_RSRQ_2_1 = np.append(mean_RSRQ_2_1, np.array([t_RSRQ_2_1.mean()]))
        #mean_RSRQ_2_1_sec = np.append(mean_RSRQ_2_1_sec, np.array([t_RSRQ_2_1_sec.mean()]))
        #mean_RSRQ_2_1_array = np.append(mean_RSRQ_2_1_array, np.array([t_RSRQ_2_1.mean(), t_RSRQ_2_1_sec.mean()]))
        cnt_RSRQ_2_1 = Counter(temp_RSRQ_2_1[temp_index_2_1])
        if not list(cnt_RSRQ_2_1):
            #count_RSRQ_2_1 = np.append(count_RSRQ_2_1, [np.nan, np.nan])
            count_RSRQ_2_1 = np.append(count_RSRQ_2_1, np.nan)
        else:
            #if len(cnt_RSRQ_2_1.most_common()) >= 2:
            #    tt_count_RSRQ_2_1 = np.array([cnt_RSRQ_2_1.most_common(2)[0][0], cnt_RSRQ_2_1.most_common(2)[1][0]])
            #elif len(cnt_RSRQ_2_1.most_common()) == 1:
            #    tt_count_RSRQ_2_1 = np.array([cnt_RSRQ_2_1.most_common(1)[0][0], cnt_RSRQ_2_1.most_common(1)[0][0]])
            #count_RSRQ_2_1 = np.append(count_RSRQ_2_1, tt_count_RSRQ_2_1)
            count_RSRQ_2_1 = np.append(count_RSRQ_2_1, np.array([cnt_RSRQ_2_1.most_common(1)[0][0]]))
        t_RSRQ_2_2 = temp_RSRQ_2_2[temp_index_2_2]
        #mean_RSRQ_2_2 = np.append(mean_RSRQ_2_2, np.array([t_RSRQ_2_2.mean()]))
        #cnt_RSRQ_2_2 = Counter(t_RSRQ_2_2)
        #t_index_2_2 = np.where(t_BS_2_2 == tt_BS_2_2[0])
        #t_RSRQ_2_2 = temp_RSRQ_2_2[t_index_2_2]
        #t_index_2_2_sec = np.where(t_BS_2_2 == tt_BS_2_2[1])
        #t_RSRQ_2_2_sec = temp_RSRQ_2_2[t_index_2_2_sec]
        mean_RSRQ_2_2 = np.append(mean_RSRQ_2_2, np.array([t_RSRQ_2_2.mean()]))
        #mean_RSRQ_2_2_sec = np.append(mean_RSRQ_2_2_sec, np.array([t_RSRQ_2_2_sec.mean()]))
        #mean_RSRQ_2_2_array = np.append(mean_RSRQ_2_2_array, np.array([t_RSRQ_2_2.mean(), t_RSRQ_2_2_sec.mean()]))
        cnt_RSRQ_2_2 = Counter(temp_RSRQ_2_2[temp_index_2_2])
        if not list(cnt_RSRQ_2_2):
            #count_RSRQ_2_2 = np.append(count_RSRQ_2_2, [np.nan, np.nan])
            count_RSRQ_2_2 = np.append(count_RSRQ_2_2, np.nan)
        else:
            #if len(cnt_RSRQ_2_2.most_common()) >= 2:
            #    tt_count_RSRQ_2_2 = np.array([cnt_RSRQ_2_2.most_common(2)[0][0], cnt_RSRQ_2_2.most_common(2)[1][0]])
            #elif len(cnt_RSRQ_2_2.most_common()) == 1:
            #    tt_count_RSRQ_2_2 = np.array([cnt_RSRQ_2_2.most_common(1)[0][0], cnt_RSRQ_2_2.most_common(1)[0][0]])
            #count_RSRQ_2_2 = np.append(count_RSRQ_2_2, tt_count_RSRQ_2_2)
            count_RSRQ_2_2 = np.append(count_RSRQ_2_2, np.array([cnt_RSRQ_2_2.most_common(1)[0][0]]))

        mean_index_1_1 = np.append(mean_index_1_1, i * np.ones(len(temp_index_1_1)))
        mean_index_1_2 = np.append(mean_index_1_2, i * np.ones(len(temp_index_1_2)))
        mean_index_2_1 = np.append(mean_index_2_1, i * np.ones(len(temp_index_2_1)))
        mean_index_2_2 = np.append(mean_index_2_2, i * np.ones(len(temp_index_2_2)))





    #final_mean_RSRP_1_1 = np.append(mean_RSRP_1_1, final_mean_RSRP_1_1)
    #final_mean_RSRP_1_2 = np.append(mean_RSRP_2_2, final_mean_RSRP_1_2)
    #final_mean_RSRP_2_1 = np.append(mean_RSRP_2_1, final_mean_RSRP_2_1)
    #final_mean_RSRP_2_2 = np.append(mean_RSRP_2_2, final_mean_RSRP_2_2)
    #print('temp_RSRP_1_1 = ', len(temp_RSRP_1_1))

    #final_mean_RSSI_1_1 = np.append(mean_RSSI_1_1, final_mean_RSSI_1_1)
    #final_mean_RSSI_1_2 = np.append(mean_RSSI_1_2, final_mean_RSSI_1_2)
    #final_mean_RSSI_2_1 = np.append(mean_RSSI_2_1, final_mean_RSSI_2_1)
    #final_mean_RSSI_2_2 = np.append(mean_RSSI_2_2, final_mean_RSSI_2_2)

    #temp_RSRQ_1_1 = RSRQ_1_1[index_1_1]
    #temp_RSRQ_1_2 = RSRQ_1_2[index_1_2]
    #temp_RSRQ_2_1 = RSRQ_2_1[index_2_1]
    #temp_RSRQ_2_2 = RSRQ_2_2[index_2_2]

    #print(count_RSRP_1_1)


length_data = len(R_BS_1_1)
print('BS_length = ', len(R_BS_1_1))
print('RSRP_length = ', len(mean_RSRP_1_1_array))

np.savetxt('mean_RSRP_1_1_5_re.txt', mean_RSRP_1_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSRP_1_2_5_re.txt', mean_RSRP_1_2, fmt='%s', delimiter=',')
np.savetxt('mean_RSRP_2_1_5_re.txt', mean_RSRP_2_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSRP_2_2_5_re.txt', mean_RSRP_2_2, fmt='%s', delimiter=',')

np.savetxt('mean_RSSI_1_1_5_re.txt', mean_RSSI_1_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSSI_1_2_5_re.txt', mean_RSSI_1_2, fmt='%s', delimiter=',')
np.savetxt('mean_RSSI_2_1_5_re.txt', mean_RSSI_2_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSSI_2_2_5_re.txt', mean_RSSI_2_2, fmt='%s', delimiter=',')

np.savetxt('mean_RSRQ_1_1_5_re.txt', mean_RSRQ_1_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSRQ_1_2_5_re.txt', mean_RSRQ_1_2, fmt='%s', delimiter=',')
np.savetxt('mean_RSRQ_2_1_5_re.txt', mean_RSRQ_2_1, fmt='%s', delimiter=',')
np.savetxt('mean_RSRQ_2_2_5_re.txt', mean_RSRQ_2_2, fmt='%s', delimiter=',')

#np.savetxt('mean_index_1_1_5_re.txt', mean_index_1_1, fmt='%s', delimiter=',')
#np.savetxt('mean_index_1_2_5_re.txt', mean_index_1_2, fmt='%s', delimiter=',')
#np.savetxt('mean_index_2_1_5_re.txt', mean_index_2_1, fmt='%s', delimiter=',')
#np.savetxt('mean_index_2_2_5_re.txt', mean_index_2_2, fmt='%s', delimiter=',')

np.savetxt('R_BS_1_1_5_re.txt', R_BS_1_1, fmt='%s', delimiter=',')
np.savetxt('R_BS_1_2_5_re.txt', R_BS_1_2, fmt='%s', delimiter=',')
np.savetxt('R_BS_2_1_5_re.txt', R_BS_2_1, fmt='%s', delimiter=',')
np.savetxt('R_BS_2_2_5_re.txt', R_BS_2_2, fmt='%s', delimiter=',')

#print(count_RSRP_1_1.size)
#print(count_RSRP_2_2.size)

np.savetxt('count_RSRP_1_1_5_re.txt', count_RSRP_1_1, fmt='%s', delimiter=',')
np.savetxt('count_RSRP_1_2_5_re.txt', count_RSRP_1_2, fmt='%s', delimiter=',')
np.savetxt('count_RSRP_2_1_5_re.txt', count_RSRP_2_1, fmt='%s', delimiter=',')
np.savetxt('count_RSRP_2_2_5_re.txt', count_RSRP_2_2, fmt='%s', delimiter=',')

np.savetxt('count_RSSI_1_1_5_re.txt', count_RSSI_1_1, fmt='%s', delimiter=',')
np.savetxt('count_RSSI_1_2_5_re.txt', count_RSSI_1_2, fmt='%s', delimiter=',')
np.savetxt('count_RSSI_2_1_5_re.txt', count_RSSI_2_1, fmt='%s', delimiter=',')
np.savetxt('count_RSSI_2_2_5_re.txt', count_RSSI_2_2, fmt='%s', delimiter=',')

np.savetxt('count_RSRQ_1_1_5_re.txt', count_RSRP_1_1, fmt='%s', delimiter=',')
np.savetxt('count_RSRQ_1_2_5_re.txt', count_RSRP_1_2, fmt='%s', delimiter=',')
np.savetxt('count_RSRQ_2_1_5_re.txt', count_RSRP_2_1, fmt='%s', delimiter=',')
np.savetxt('count_RSRQ_2_2_5_re.txt', count_RSRP_2_2, fmt='%s', delimiter=',')

#np.savetxt('mean_index_1_1_10_re.txt', mean_index_1_1, fmt='%s', delimiter=',')
#np.savetxt('mean_index_1_2_10_re.txt', mean_index_1_2, fmt='%s', delimiter=',')
#np.savetxt('mean_index_2_1_10_re.txt', mean_index_2_1, fmt='%s', delimiter=',')
#np.savetxt('mean_index_2_2_10_re.txt', mean_index_2_2, fmt='%s', delimiter=',')

#np.savetxt('R_BS_1_1_10_re.txt', R_BS_1_1, fmt='%s', delimiter=',')
#np.savetxt('R_BS_1_2_10_re.txt', R_BS_1_2, fmt='%s', delimiter=',')
#np.savetxt('R_BS_2_1_10_re.txt', R_BS_2_1, fmt='%s', delimiter=',')
#np.savetxt('R_BS_2_2_10_re.txt', R_BS_2_2, fmt='%s', delimiter=',')

print("time :", time.time() - start)