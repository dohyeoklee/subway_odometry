import numpy as np

import time
import logging_data
import math
import pandas as pd
import random
import matplotlib.pyplot as plt


start = time.time()

BS_1_1 = np.loadtxt('R_BS_1_1_5_up.txt', delimiter=',')
BS_1_2 = np.loadtxt('R_BS_1_2_5_up.txt', delimiter=',')
BS_2_1 = np.loadtxt('R_BS_2_1_5_up.txt', delimiter=',')
BS_2_2 = np.loadtxt('R_BS_2_2_5_up.txt', delimiter=',')

print('len_BS_1_1 = ', len(BS_1_1))

#print(BS_1_1)

#BS_1_1 = np.array([BS_1_1])
#BS_1_2 = np.array([BS_1_2])
#BS_2_1 = np.array([BS_2_1])
#BS_2_2 = np.array([BS_2_2])

#count_RSRP_1_1 = np.loadtxt('count_RSRP_1_1_5_re.txt', delimiter=',')
#count_RSRP_1_2 = np.loadtxt('count_RSRP_1_2_5_re.txt', delimiter=',')
#count_RSRP_2_1 = np.loadtxt('count_RSRP_2_1_5_re.txt', delimiter=',')
#count_RSRP_2_2 = np.loadtxt('count_RSRP_2_2_5_re.txt', delimiter=',')

count_RSRP_1_1 = np.loadtxt('mean_RSRP_1_1_5_up.txt', delimiter=',')
count_RSRP_1_2 = np.loadtxt('mean_RSRP_1_2_5_up.txt', delimiter=',')
count_RSRP_2_1 = np.loadtxt('mean_RSRP_2_1_5_up.txt', delimiter=',')
count_RSRP_2_2 = np.loadtxt('mean_RSRP_2_2_5_up.txt', delimiter=',')

#count_RSRP_1_1 = np.array([count_RSRP_1_1])
#count_RSRP_1_2 = np.array([count_RSRP_1_2])
#count_RSRP_2_1 = np.array([count_RSRP_2_1])
#count_RSRP_2_2 = np.array([count_RSRP_2_2])

#count_RSSI_1_1 = np.loadtxt('count_RSSI_1_1_5_re.txt', delimiter=',')
#count_RSSI_1_2 = np.loadtxt('count_RSSI_1_2_5_re.txt', delimiter=',')
#count_RSSI_2_1 = np.loadtxt('count_RSSI_2_1_5_re.txt', delimiter=',')
#count_RSSI_2_2 = np.loadtxt('count_RSSI_2_2_5_re.txt', delimiter=',')

count_RSSI_1_1 = np.loadtxt('mean_RSSI_1_1_5_up.txt', delimiter=',')
count_RSSI_1_2 = np.loadtxt('mean_RSSI_1_2_5_up.txt', delimiter=',')
count_RSSI_2_1 = np.loadtxt('mean_RSSI_2_1_5_up.txt', delimiter=',')
count_RSSI_2_2 = np.loadtxt('mean_RSSI_2_2_5_up.txt', delimiter=',')

#count_RSSI_1_1 = np.array([count_RSSI_1_1])
#count_RSSI_1_2 = np.array([count_RSSI_1_2])
#count_RSSI_2_1 = np.array([count_RSSI_2_1])
#count_RSSI_2_2 = np.array([count_RSSI_2_2])

count_RSRQ_1_1 = np.loadtxt('mean_RSRQ_1_1_5_up.txt', delimiter=',')
count_RSRQ_1_2 = np.loadtxt('mean_RSRQ_1_2_5_up.txt', delimiter=',')
count_RSRQ_2_1 = np.loadtxt('mean_RSRQ_2_1_5_up.txt', delimiter=',')
count_RSRQ_2_2 = np.loadtxt('mean_RSRQ_2_2_5_up.txt', delimiter=',')

#mean_index_1_1 = np.loadtxt('mean_index_1_1_10.txt', delimiter=',', dtype='int')
#mean_index_1_2 = np.loadtxt('mean_index_1_2_10.txt', delimiter=',', dtype='int')
#mean_index_2_1 = np.loadtxt('mean_index_2_1_10.txt', delimiter=',', dtype='int')
#mean_index_2_2 = np.loadtxt('mean_index_2_2_10.txt', delimiter=',', dtype='int')

#date = ['1013','1014','1015','1016','1018']
date = ['1013']
#num_car = [27,33]
num_car = [27]

block_length = 5
max_interval_length = 1974
num_block = math.ceil(max_interval_length/block_length)

print(num_block)

window = 15
t_win = 3
#m_para = 5
#back_window = 3
m_index = 3
dummy_index2 = 18
dummy_index1 = 18

limit_gap_distance = 300

#print('A = ', BS_1_1[(25+1)*num_block:(25+2)*num_block])

Pos_error = np.array([])

FINAL_TRAIN_ID = ['운연']
NEXT_TRAIN_ID = ['운연','인천대공원','남동구청','만수','모래내시장','석천사거리','인천시청','석바위시장','시민공원','주안',
                 '주안국가산단','가재울','인천가좌','서부여성회관','석남','가정중앙시장','가정','서구청','아시아드경기장','검바위',
                 '검암','독정','완정','마전','검단사거리','왕길']

NEXT_TRAIN_ID_ENG = ['Incheon Grand Prak', 'Namdong-gu Office', 'Mansu', 'Moraenae Market', 'Seokcheon Sageori', 'Incheon City Hall', 'Seokbawi Market',
                     'Citizens Park', 'Juan', 'Juan National Industrial Complex', 'Gajaeul', 'Incheon Gajwa', 'West Womans Community Center',
                     'Seongnam', 'Gajeong Jungang Market', 'Gajeong', 'Seo-gu Office', 'Asiad Stadium', 'Geombawi', 'Geomam', 'Dokjeong', 'Wangeong', 'Majeon',
                     'Gomdan Sageori', 'Wangil', 'Geomdan Oryu']

NEXT_TRAIN_ID.reverse()

print('len_next_station = ', len(NEXT_TRAIN_ID))
#print('next_train_id = ', NEXT_TRAIN_ID)

temp_distance = 0

error_sum = np.zeros(len(NEXT_TRAIN_ID))
error_num = np.zeros(len(NEXT_TRAIN_ID))

for i in num_car:
    for j in date:
        #print(j)
        car_data0 = logging_data.car_data(i, j, pd)
        terminal_data0 = logging_data.terminal_data(i, j, pd)

        car_data_time = car_data0['Time']
        car_data_next_train_id = car_data0['Next Train ID']
        car_data_final_train_id = car_data0['Final Train ID']
        car_data_distance = car_data0['Distance from station']
        car_data_train_speed = car_data0['Train Speed']
        #print('car_distance = ', car_data_distance[30040])

        terminal_data_time = terminal_data0['Time']
        terminal_data_BS_1_1 = terminal_data0['BS_1_1']
        terminal_data_RSRP_1_1 = terminal_data0['RSRP_1_1']
        terminal_data_RSSI_1_1 = terminal_data0['RSSI_1_1']
        terminal_data_RSRQ_1_1 = terminal_data0['RSRQ_1_1']
        terminal_data_BS_1_2 = terminal_data0['BS_1_2']
        terminal_data_RSRP_1_2 = terminal_data0['RSRP_1_2']
        terminal_data_RSSI_1_2 = terminal_data0['RSSI_1_2']
        terminal_data_RSRQ_1_2 = terminal_data0['RSRQ_1_2']
        terminal_data_BS_2_1 = terminal_data0['BS_2_1']
        terminal_data_RSRP_2_1 = terminal_data0['RSRP_2_1']
        terminal_data_RSSI_2_1 = terminal_data0['RSSI_2_1']
        terminal_data_RSRQ_2_1 = terminal_data0['RSRQ_2_1']
        terminal_data_BS_2_2 = terminal_data0['BS_2_2']
        terminal_data_RSRP_2_2 = terminal_data0['RSRP_2_2']
        terminal_data_RSSI_2_2 = terminal_data0['RSSI_2_2']
        terminal_data_RSRQ_2_2 = terminal_data0['RSRQ_2_2']

        # print(np.isnan(terminal_data_RSRP_1_2))

        list_car_data_time = list(car_data_time)
        len_car_data_time = len(list_car_data_time)
        list_car_data_final_train_id = list(car_data_final_train_id)
        list_car_data_next_train_id = list(car_data_next_train_id)
        #print('len_terminal_data_time = ', len(terminal_data_time))
        #temp = np.array([0])
        temp = 0
        temp_estimated_distance = 0
        counter = 0
        #start = 0
        for k in range(len(terminal_data_time)):
            for n in range(len(FINAL_TRAIN_ID)):
                #if n > 0:
                    if str(terminal_data_time[k]) in list_car_data_time:
                        time1 = list_car_data_time.index(str(terminal_data_time[k]))
                        char_dist = car_data_distance[time1].split('(')
                        distance = int(char_dist[0])
                        if time1:
                            val = FINAL_TRAIN_ID[n] in car_data_final_train_id[time1]
                            if distance > 0:
                                #if temp_distance != distance:
                                #print(car_data_final_train_id[time1])
                                if val:
                                    if np.isnan(terminal_data_BS_1_1[k]) == False and np.isnan(terminal_data_BS_2_1[k]) == False:
                                        temp_BS_1_1 = np.array([])
                                        temp_BS_2_1 = np.array([])
                                        if k > 0:
                                            pre_temp_BS_set = np.array([terminal_data_BS_1_1[k-1], terminal_data_BS_2_1[k-1]])
                                        temp_BS_set = np.array([terminal_data_BS_1_1[k], terminal_data_BS_2_1[k]])
                                        #print('pre_temp_BS_set = ', pre_temp_BS_set)
                                        #print('temp_BS_set = ', temp_BS_set)
                                        if n == 0 and car_data_next_train_id[time1] != '-':
                                            station_name = car_data_next_train_id[time1].split('(')
                                            if station_name[0] != '검단오류':
                                                num = [q for q in range(len(NEXT_TRAIN_ID)) if station_name[0] == NEXT_TRAIN_ID[q]]
                                                if temp != num[0]:
                                                    temp_distance = 0
                                                    temp_estimated_distance = 0
                                                #if temp[0] != num[0]:
                                                #    min_index = 0
                                                #print('num = ', num)
                                                #print('num = ', num)
                                                #print('k = ', k)
                                                #print(terminal_data_time[k])
                                                #print(num[0]*num_block)
                                                temp_BS_1_1 = BS_1_1[(num[0]+1)*num_block:(num[0]+2)*num_block]
                                                temp_BS_2_1 = BS_2_1[(num[0]+1)*num_block:(num[0]+2)*num_block]

                                                #print('temp_BS_1_1 = ', temp_BS_1_1)
                                                #BS_1_1_index = [q for q in range(len(temp_BS_1_1)) if terminal_data_BS_1_1[k] == temp_BS_1_1[q]]
                                                #BS_2_1_index = [q for q in range(len(temp_BS_2_1)) if terminal_data_BS_2_1[k] == temp_BS_2_1[q]]
                                                BS_index = [q for q in range(len(temp_BS_1_1)) if terminal_data_BS_1_1[k] == temp_BS_1_1[q] and terminal_data_BS_2_1[k] == temp_BS_2_1[q]]
                                                diff_RSRP = np.array([])
                                                diff_RSSI = np.array([])
                                                diff_RSRQ = np.array([])
                                                diff_sum = np.array([])
                                                c_BS_index = np.array([])
                                                #print('num = ', num[0])
                                                #print('temp = ', temp)
                                                #print('counter = ', counter)

                                                #if start == 0:  ## first time
                                                #    moving_BS_index = BS_index[0:t_win]
                                                #    start = 1
                                                #else:
                                                if num[0] == temp and np.array_equal(pre_temp_BS_set,temp_BS_set) == True:
                                                    #counter = counter + 1
                                                    #if counter > 0:
                                                    if (counter-0)*m_index-dummy_index1 >= 0 and (counter-0)*m_index+t_win+dummy_index2 >= len(BS_index):
                                                        moving_BS_index = BS_index[(counter-0)*m_index-dummy_index1:len(BS_index)]
                                                    elif (counter-0)*m_index-dummy_index1 < 0 and (counter-0)*m_index+t_win+dummy_index2 < len(BS_index):
                                                        moving_BS_index = BS_index[0:(counter-0)*m_index+t_win+dummy_index2]
                                                    elif (counter-0)*m_index-dummy_index1 < 0 and (counter-0)*m_index+t_win+dummy_index2 >= len(BS_index):
                                                        moving_BS_index = BS_index[0:len(BS_index)]
                                                    elif (counter-0)*m_index-dummy_index1 >= 0 and (counter-0)*m_index+t_win+dummy_index2 < len(BS_index):
                                                        moving_BS_index = BS_index[(counter-0)*m_index-dummy_index1:(counter-0)*m_index+t_win+dummy_index2]
                                                    #else:
                                                    #    moving_BS_index = BS_index[(counter-0)*m_index-dummy_index:(counter-0)*m_index+t_win+dummy_index]
                                                    #else:
                                                    #    moving_BS_index = BS_index[0:(counter-0)*m_index+t_win+dummy_index]
                                                    counter = counter + 1
                                                else:
                                                    counter = 0
                                                    moving_BS_index = BS_index[counter*m_index:counter*m_index+t_win]


                                                #print('BS_index = ', BS_index)
                                                #print('moving_BS_index = ', moving_BS_index)
                                                #for l in range(2 * t_win + 1):
                                                #    if min_index + l - t_win >= 0 and min_index + l - t_win < len(BS_index):
                                                #        c_BS_index = np.append(c_BS_index, np.array([int(BS_index[min_index + l - t_win])]))
                                                        #print('BS_index = ', BS_index[min_index + l - window])
                                                #print('c_BS_index = ', c_BS_index)
                                                #print('min_index = ', min_index)
                                                #print('num = ', num)
                                                if moving_BS_index != [] and len(moving_BS_index) > 1:
                                                    #print('terminal_data_BS_1_1 = ', terminal_data_BS_1_1[k])
                                                    #print(BS_index)
                                                    for j in range(len(moving_BS_index)):
                                                        #print(j)
                                                        #print(count_RSRP_2_1[num[0]*num_block+BS_index[j]])
                                                        #print(BS_index)
                                                        #print(len(BS_index))
                                                        diff_RSRP = np.append(diff_RSRP, np.array([(abs(count_RSRP_1_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRP_1_1[k]) + abs(count_RSRP_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRP_2_1[k]))*1]))
                                                        diff_RSSI = np.append(diff_RSSI, np.array([(abs(count_RSSI_1_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSSI_1_1[k]) + abs(count_RSSI_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSSI_2_1[k]))*1]))
                                                        diff_RSRQ = np.append(diff_RSRQ, np.array([(abs(count_RSRQ_1_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRQ_1_1[k]) + abs(count_RSRQ_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRQ_2_1[k]))*1]))
                                                        #print('count1 = ', abs(count_RSRP_1_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRP_1_1[k]) + abs(count_RSRP_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSRP_2_1[k]))
                                                        #print('count2 = ', abs(count_RSSI_1_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSSI_1_1[k]) + abs(count_RSSI_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])] - terminal_data_RSSI_2_1[k]))
                                                        #print('count3 = ', abs(count_RSRQ_1_1[(num[0] + 1) * num_block + int(moving_BS_index[j])]-terminal_data_RSRQ_1_1[k]) + abs(count_RSRQ_2_1[(num[0] + 1) * num_block + int(moving_BS_index[j])]-terminal_data_RSRQ_2_1[k]))
                                                        #diff_RSRP = np.append(diff_RSRP, np.array([(count_RSRP_1_1[num[0]*num_block+int(BS_index[j])]/terminal_data_RSRP_1_1[k]) + (count_RSRP_2_1[num[0]*num_block+int(BS_index[j])]/terminal_data_RSRP_2_1[k])]))
                                                        #diff_RSSI = np.append(diff_RSSI, np.array([(count_RSSI_1_1[num[0] * num_block + int(BS_index[j])] / terminal_data_RSSI_1_1[k]) + (count_RSSI_2_1[num[0] * num_block + int(BS_index[j])] / terminal_data_RSSI_2_1[k])]))
                                                        #print('count3 = ', count_RSRQ_2_1[(num[0]+1)*num_block+int(moving_BS_index[j])])

                                                    #for j in range(len(BS_2_1_index)):
                                                    #    diff_RSRP = np.append(diff_RSRP, np.array([(count_RSRP_1_1[j] - terminal_data_RSRP_1_1[k])**2 + (count_RSRP_2_1[j] - terminal_data_RSRP_2_1[k])**2]))
                                                    #    diff_RSSI = np.append(diff_RSSI, np.array([(count_RSSI_1_1[j] - terminal_data_RSSI_1_1[k])**2 + (count_RSSI_2_1[j] - terminal_data_RSSI_2_1[k])**2]))
                                                    #print('diff_RSRP = ', diff_RSRP)
                                                    #print('diff_RSSI = ', diff_RSSI)
                                                    #diff_RSSI = diff_RSRP
                                                    diff_sum = diff_RSRP + diff_RSSI + diff_RSRQ
                                                    #print(diff_RSRP)
                                                    #print('diff_sum = ', diff_sum)
                                                    min_index = np.argmin(diff_sum)
                                                    #print('min_index = ', min_index)
                                                    sort_index = np.argsort(diff_sum)
                                                    #print('sort_index = ', sort_index)
                                                    ratio = np.array([])
                                                    #print(distance)
                                                    estimated_distance = 0
                                                    #print(min_index)
                                                    '''
                                                    if min_index == 0:
                                                        for m in range(window-1):
                                                            if diff_sum[min_index+m] == 0:
                                                                diff_sum[min_index+m] = 0.0001
                                                            elif diff_sum[min_index] == 0:
                                                                diff_sum[min_index] = 0.0001
                                                            elif diff_sum[min_index+1] == 0:
                                                                diff_sum[min_index + 1] = 0.0001
                                                            ratio = np.append(ratio, np.array([(1/diff_sum[min_index+m])/(1/diff_sum[min_index]+1/diff_sum[min_index+1])]))
                                                            estimated_distance = ratio[m]*(block_length*BS_index[min_index+m] + block_length/2) + estimated_distance
                                                    elif min_index > 0 and min_index < len(diff_sum)-1:
                                                        for m in range(window):
                                                            #print(m)
                                                            if diff_sum[min_index+m-1] == 0:
                                                                diff_sum[min_index+m-1] = 0.0001
                                                            elif diff_sum[min_index] == 0:
                                                                diff_sum[min_index] = 0.0001
                                                            elif diff_sum[min_index+1] == 0:
                                                                diff_sum[min_index+1] = 0.0001
                                                            elif diff_sum[min_index-1] == 0:
                                                                diff_sum[min_index-1] = 0.0001
                                                            ratio = np.append(ratio, np.array([(1/diff_sum[min_index+m-1])/(1/diff_sum[min_index-1]+1/diff_sum[min_index]+1/diff_sum[min_index+1])]))
                                                            estimated_distance = ratio[m] * (block_length*BS_index[min_index + m-1] + block_length/2) + estimated_distance
                                                    elif min_index == len(diff_sum)-1:
                                                        for m in range(window-1):
                                                            if diff_sum[min_index] == 0:
                                                                diff_sum[min_index] = 0.0001
                                                            elif diff_sum[min_index-1] == 0:
                                                                diff_sum[min_index-1] = 0.0001
                                                            ratio = np.append(ratio, np.array([(1/diff_sum[min_index-m])/(1/diff_sum[min_index]+1/diff_sum[min_index-1])]))
                                                            estimated_distance = ratio[m]*(block_length*BS_index[min_index-m] + block_length/2) + estimated_distance
        
                                                    Pos_error = np.append(Pos_error, np.array([abs(distance - estimated_distance)]))
                                                    #print('Pos_error = ', abs(distance - estimated_distance))
                                                    #print(diff_sum)
                                                    '''


                                                    temp_ratio = 0
                                                    if len(sort_index) >= window:
                                                        for m in range(window):
                                                            if diff_sum[sort_index[m]] == 0:
                                                                diff_sum[sort_index[m]] = 0.001
                                                            temp_ratio = temp_ratio + 1/diff_sum[sort_index[m]]
                                                        for m in range(window):
                                                            ratio = np.append(ratio, np.array([(1/diff_sum[sort_index[m]])/temp_ratio]))
                                                            estimated_distance = ratio[m]*(block_length*moving_BS_index[sort_index[m]]+block_length/2) + estimated_distance
                                                        Pos_error = np.append(Pos_error, np.array([abs(distance - estimated_distance)]))
                                                        error_sum[num[0]] = error_sum[num[0]] + abs(distance - estimated_distance)
                                                        error_num[num[0]] = error_num[num[0]] + 1
                                                    elif len(sort_index) < window and sort_index != []:
                                                        for m in range(len(sort_index)):
                                                            if diff_sum[sort_index[m]] == 0:
                                                                diff_sum[sort_index[m]] = 0.001
                                                            temp_ratio = temp_ratio + 1 / diff_sum[sort_index[m]]
                                                        for m in range(len(sort_index)):
                                                            ratio = np.append(ratio, np.array([(1 / diff_sum[sort_index[m]]) / temp_ratio]))
                                                            estimated_distance = ratio[m] * (block_length * moving_BS_index[sort_index[m]]+block_length/2) + estimated_distance
                                                        Pos_error = np.append(Pos_error, np.array([abs(distance - estimated_distance)]))
                                                        error_sum[num[0]] = error_sum[num[0]] + abs(distance - estimated_distance)
                                                        error_num[num[0]] = error_num[num[0]] + 1
                                                    #print('ratio = ', ratio)

                                                elif moving_BS_index != [] and len(moving_BS_index) == 1:
                                                    #diff_RSRP = np.append(diff_RSRP, np.array([(count_RSRP_1_1[num[0] * num_block + BS_index[j]] - terminal_data_RSRP_1_1[k]) ** 2 + (count_RSRP_2_1[num[0] * num_block + BS_index[j]] - terminal_data_RSRP_2_1[k]) ** 2]))
                                                    #diff_RSSI = np.append(diff_RSSI, np.array([(count_RSSI_1_1[num[0] * num_block + BS_index[j]] - terminal_data_RSSI_1_1[k]) ** 2 + (count_RSSI_2_1[num[0] * num_block + BS_index[j]] - terminal_data_RSSI_2_1[k]) ** 2]))
                                                    estimated_distance = block_length*moving_BS_index[0] + block_length/2
                                                    Pos_error = np.append(Pos_error, np.array([abs(distance - estimated_distance)]))
                                                    error_sum[num[0]] = error_sum[num[0]] + abs(distance - estimated_distance)
                                                    error_num[num[0]] = error_num[num[0]] + 1

                                                elif moving_BS_index == []:
                                                    #estimated_distance = block_length / 2
                                                    Pos_error = np.append(Pos_error, np.array([abs(distance - estimated_distance)]))
                                                    error_sum[num[0]] = error_sum[num[0]] + abs(distance - estimated_distance)
                                                    error_num[num[0]] = error_num[num[0]] + 1

                                                temp = num[0]

                                                #if abs(temp_estimated_distance - estimated_distance) > limit_gap_distance:
                                                #    r_number = abs(10*random.random())
                                                #    estimated_distance = temp_estimated_distance + r_number

                                                temp_estimated_distance = estimated_distance
                                                #print('estimated_distance = ', estimated_distance)
                                                if abs(distance - estimated_distance) > 200:
                                                    print('big error case = ', terminal_data_time[k])

                                                #print('k = ', k)
                                                #print('distance = ', distance)
                                                #print('estimated_distance = ', estimated_distance)
                                                #print('Pos_error = ', abs(distance - estimated_distance))
                                                #print('ratio = ', ratio)
                                                #print('estimated_distance = ', estimated_distance)
                                #temp_distance = distance


#print(Pos_error)
#print(len(Pos_error))
mean_error = np.zeros(len(NEXT_TRAIN_ID))
x = np.zeros(len(NEXT_TRAIN_ID))
for i in range(len(NEXT_TRAIN_ID)):
    mean_error[i] = error_sum[i]/error_num[i]
    x[i] = i
    print(f'mean_error {i} = {mean_error[i]}')

plt.title('Wireless Communication based Metro Position Error In Incheon Line no. 2')
x = range(len(NEXT_TRAIN_ID))
plt.bar(x, mean_error)
plt.xticks(x, NEXT_TRAIN_ID_ENG, rotation = 60)
plt.show()
len_pos_error = len(Pos_error)
sort_pos_error = np.sort(Pos_error)
print('Mean of Position error = ', Pos_error.mean())
print('max = ', Pos_error.max())
print('min = ', Pos_error.min())
print('worst 5% = ', sort_pos_error[int(np.ceil(len_pos_error*0.95))])

print("time :", time.time() - start)