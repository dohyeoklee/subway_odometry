import torch
import math
import torch.nn as nn
import torch.nn.functional as L
from torch.utils.data import DataLoader
from torch.distributions.multivariate_normal import MultivariateNormal
import random

from torch.utils.data import Dataset
import scipy.io as io
import scipy.constants as sc
import numpy as np
import pandas as pd
from openpyxl import load_workbook
import time
import logging_data

start = time.time()

date = ['0901','0902','0906','0907','0908','0909','0929','0930','1001','1002','1005','1006','1007']
#date = ['0901']

#car_data = pd.read_excel('DN210901-000000-CN2127.xlsx', engine = 'openpyxl')
#terminal_data27 = pd.read_excel('233_210901_210914.xlsx', sheet_name = '0914',engine = 'openpyxl')
num_car = [27,33]
#num_car = [33]

block_length = 5

#FINAL_TRAIN_ID = ['운연','검단오류']
FINAL_TRAIN_ID = ['운연']
NEXT_TRAIN_ID = ['운연','인천대공원','남동구청','만수','모래내시장','석천사거리','인천시청','석바위시장','시민공원','주안',
                 '주안국가산단','가재울','인천가좌','서부여성회관','석남','가정중앙시장','가정','서구청','아시아드경기장','검바위',
                 '검암','독정','완정','마전','검단사거리','왕길','검단오류']

NEXT_TRAIN_ID.reverse()

print('next_train_id = ', NEXT_TRAIN_ID)

BS_1_1_a = np.array([])
BS_1_2_a = np.array([])
BS_2_1_a = np.array([])
BS_2_2_a = np.array([])

RSRP_1_1_a = np.array([])
RSRP_1_2_a = np.array([])
RSRP_2_1_a = np.array([])
RSRP_2_2_a = np.array([])

RSSI_1_1_a = np.array([])
RSSI_1_2_a = np.array([])
RSSI_2_1_a = np.array([])
RSSI_2_2_a = np.array([])

RSRQ_1_1_a = np.array([])
RSRQ_1_2_a = np.array([])
RSRQ_2_1_a = np.array([])
RSRQ_2_2_a = np.array([])

distance = np.array([])
time3 = np.array([])

index1 = np.array([],dtype=np.int64)

up_next_station = np.array([])
down_next_station = np.array([])

for i in num_car:
    for j in date:
        print(j)
        car_data0 = logging_data.car_data(i,j,pd)
        terminal_data0 = logging_data.terminal_data(i,j,pd)

        car_data_time = car_data0['Time']
        car_data_next_train_id = car_data0['Next Train ID']
        car_data_final_train_id = car_data0['Final Train ID']
        car_data_distance = car_data0['Distance from station']
        car_data_train_speed = car_data0['Train Speed']

        terminal_data_time = terminal_data0['Time']
        terminal_data_BS_1_1 = terminal_data0['BS_1_1']
        terminal_data_RSRP_1_1 = terminal_data0['RSRP_1_1']
        terminal_data_RSSI_1_1 = terminal_data0['RSSI_1_1']
        terminal_data_RSRQ_1_1 = terminal_data0['RSRQ_1_1']
        terminal_data_BS_1_2 = terminal_data0['BS_1_2']
        terminal_data_RSRP_1_2 = terminal_data0['RSRP_1_2']
        terminal_data_RSSI_1_2 = terminal_data0['RSSI_1_2']
        terminal_data_RSRQ_1_2 = terminal_data0['RSRQ_1_2']
        terminal_data_BS_2_1 = terminal_data0['BS_2_1']
        terminal_data_RSRP_2_1 = terminal_data0['RSRP_2_1']
        terminal_data_RSSI_2_1 = terminal_data0['RSSI_2_1']
        terminal_data_RSRQ_2_1 = terminal_data0['RSRQ_2_1']
        terminal_data_BS_2_2 = terminal_data0['BS_2_2']
        terminal_data_RSRP_2_2 = terminal_data0['RSRP_2_2']
        terminal_data_RSSI_2_2 = terminal_data0['RSSI_2_2']
        terminal_data_RSRQ_2_2 = terminal_data0['RSRQ_2_2']

        #print(np.isnan(terminal_data_RSRP_1_2))

        list_car_data_time = list(car_data_time)
        len_car_data_time = len(list_car_data_time)
        list_car_data_final_train_id = list(car_data_final_train_id)
        list_car_data_next_train_id = list(car_data_next_train_id)

        for k in range(len(terminal_data_time)):
            for n in range(len(FINAL_TRAIN_ID)):
                if str(terminal_data_time[k]) in list_car_data_time:
                    time1 = list_car_data_time.index(str(terminal_data_time[k]))
                    char_dist = car_data_distance[time1].split('(')
                    dist = int(char_dist[0])
                    if time1:
                        val = FINAL_TRAIN_ID[n] in car_data_final_train_id[time1]
                        if dist > 0:
                        #print(car_data_final_train_id[time1])
                            if val:
                                if np.isnan(terminal_data_BS_1_1[k]) == False or np.isnan(terminal_data_BS_1_2[k]) == False or np.isnan(terminal_data_BS_2_1[k]) == False or np.isnan(terminal_data_BS_2_2[k]) == False:
                                    if n == 0 and car_data_next_train_id[time1] != '-':
                                        #str_dist = car_data_distance[time1].split(' ')
                                        #dist = int(str_dist[0])
                                        time3 = np.append(time3, np.array([time1]))
                                        distance = np.append(distance, np.array([dist]))
                                        BS_1_1_a = np.append(BS_1_1_a, np.array([terminal_data_BS_1_1[k]]))
                                        BS_1_2_a = np.append(BS_1_2_a, np.array([terminal_data_BS_1_2[k]]))
                                        BS_2_1_a = np.append(BS_2_1_a, np.array([terminal_data_BS_2_1[k]]))
                                        BS_2_2_a = np.append(BS_2_2_a, np.array([terminal_data_BS_2_2[k]]))
                                        RSRP_1_1_a = np.append(RSRP_1_1_a, np.array([terminal_data_RSRP_1_1[k]]))
                                        RSRP_1_2_a = np.append(RSRP_1_2_a, np.array([terminal_data_RSRP_1_2[k]]))
                                        RSRP_2_1_a = np.append(RSRP_2_1_a, np.array([terminal_data_RSRP_2_1[k]]))
                                        RSRP_2_2_a = np.append(RSRP_2_2_a, np.array([terminal_data_RSRP_2_2[k]]))
                                        RSSI_1_1_a = np.append(RSSI_1_1_a, np.array([terminal_data_RSSI_1_1[k]]))
                                        RSSI_1_2_a = np.append(RSSI_1_2_a, np.array([terminal_data_RSSI_1_2[k]]))
                                        RSSI_2_1_a = np.append(RSSI_2_1_a, np.array([terminal_data_RSSI_2_1[k]]))
                                        RSSI_2_2_a = np.append(RSSI_2_2_a, np.array([terminal_data_RSSI_2_2[k]]))
                                        RSRQ_1_1_a = np.append(RSRQ_1_1_a, np.array([terminal_data_RSRQ_1_1[k]]))
                                        RSRQ_1_2_a = np.append(RSRQ_1_2_a, np.array([terminal_data_RSRQ_1_2[k]]))
                                        RSRQ_2_1_a = np.append(RSRQ_2_1_a, np.array([terminal_data_RSRQ_2_1[k]]))
                                        RSRQ_2_2_a = np.append(RSRQ_2_2_a, np.array([terminal_data_RSRQ_2_2[k]]))
                                        station_name = car_data_next_train_id[time1].split('(')
                                        num = [q for q in range(len(NEXT_TRAIN_ID)) if station_name[0] == NEXT_TRAIN_ID[q]]
                                        down_next_station = np.append(down_next_station, np.array([num]))
                                        #index1 = np.append(index1,k)
                                        #print(RSRP_1_1)
        #print(index1[-1])
        #print(len(down_next_station))
        index_1_1 = np.argwhere(~np.isnan(BS_1_1_a))
        index_1_2 = np.argwhere(~np.isnan(BS_1_2_a))
        index_2_1 = np.argwhere(~np.isnan(BS_2_1_a))
        index_2_2 = np.argwhere(~np.isnan(BS_2_2_a))
        BS_1_1 = BS_1_1_a[index_1_1]
        BS_1_2 = BS_1_2_a[index_1_2]
        BS_2_1 = BS_2_1_a[index_2_1]
        BS_2_2 = BS_2_2_a[index_2_2]
        RSRP_1_1 = RSRP_1_1_a[index_1_1]
        RSRP_1_2 = RSRP_1_2_a[index_1_2]
        RSRP_2_1 = RSRP_2_1_a[index_2_1]
        RSRP_2_2 = RSRP_2_2_a[index_2_2]
        RSSI_1_1 = RSSI_1_1_a[index_1_1]
        RSSI_1_2 = RSSI_1_2_a[index_1_2]
        RSSI_2_1 = RSSI_2_1_a[index_2_1]
        RSSI_2_2 = RSSI_2_2_a[index_2_2]
        RSRQ_1_1 = RSRQ_1_1_a[index_1_1]
        RSRQ_1_2 = RSRQ_1_2_a[index_1_2]
        RSRQ_2_1 = RSRQ_2_1_a[index_2_1]
        RSRQ_2_2 = RSRQ_2_2_a[index_2_2]

        next_station_1_1 = down_next_station[index_1_1]
        next_station_1_2 = down_next_station[index_1_2]
        next_station_2_1 = down_next_station[index_2_1]
        next_station_2_2 = down_next_station[index_2_2]

        dist_1_1 = distance[index_1_1]
        dist_1_2 = distance[index_1_2]
        dist_2_1 = distance[index_2_1]
        dist_2_2 = distance[index_2_2]
        #BS_1_1_b = [x for x in BS_1_1_a if np.isnan(x) == False]
        #print(len(BS_1_1_b))
        #BS_1_1 = [BS_1_1_b[m] for m in index1]
        #print(distance)
        print('BS_1_1_size = ', BS_1_1.size)
        print('BS_1_2_size = ', BS_1_2.size)
        print('BS_2_1_size = ', BS_2_1.size)
        print('BS_2_2_size = ', BS_2_2.size)
        print('station_1_1_size = ', next_station_1_1.size)
        print('station_1_2_size = ', next_station_1_2.size)
        print('station_2_1_size = ', next_station_2_1.size)
        print('station_2_2_size = ', next_station_2_2.size)

np.savetxt('BS_1_1_up.txt', BS_1_1, fmt='%d', delimiter=',')
np.savetxt('BS_1_2_up.txt', BS_1_2, fmt='%d', delimiter=',')
np.savetxt('BS_2_1_up.txt', BS_2_1, fmt='%d', delimiter=',')
np.savetxt('BS_2_2_up.txt', BS_2_2, fmt='%d', delimiter=',')

np.savetxt('RSRP_1_1_up.txt', RSRP_1_1, fmt='%d', delimiter=',')
np.savetxt('RSRP_1_2_up.txt', RSRP_1_2, fmt='%d', delimiter=',')
np.savetxt('RSRP_2_1_up.txt', RSRP_2_1, fmt='%d', delimiter=',')
np.savetxt('RSRP_2_2_up.txt', RSRP_2_2, fmt='%d', delimiter=',')

np.savetxt('RSSI_1_1_up.txt', RSSI_1_1, fmt='%d', delimiter=',')
np.savetxt('RSSI_1_2_up.txt', RSSI_1_2, fmt='%d', delimiter=',')
np.savetxt('RSSI_2_1_up.txt', RSSI_2_1, fmt='%d', delimiter=',')
np.savetxt('RSSI_2_2_up.txt', RSSI_2_2, fmt='%d', delimiter=',')

np.savetxt('next_station_1_1_up.txt', next_station_1_1, fmt='%d', delimiter=',')
np.savetxt('next_station_1_2_up.txt', next_station_1_2, fmt='%d', delimiter=',')
np.savetxt('next_station_2_1_up.txt', next_station_2_1, fmt='%d', delimiter=',')
np.savetxt('next_station_2_2_up.txt', next_station_2_2, fmt='%d', delimiter=',')

np.savetxt('dist_1_1_up.txt', dist_1_1, fmt='%d', delimiter=',')
np.savetxt('dist_1_2_up.txt', dist_1_2, fmt='%d', delimiter=',')
np.savetxt('dist_2_1_up.txt', dist_2_1, fmt='%d', delimiter=',')
np.savetxt('dist_2_2_up.txt', dist_2_2, fmt='%d', delimiter=',')

np.savetxt('down_next_station_up.txt', down_next_station, fmt='%d', delimiter=',')

np.savetxt('distance_up.txt', distance, fmt='%d', delimiter=',')

np.savetxt('RSRQ_1_1_up.txt', RSRQ_1_1, fmt='%d', delimiter=',')
np.savetxt('RSRQ_1_2_up.txt', RSRQ_1_2, fmt='%d', delimiter=',')
np.savetxt('RSRQ_2_1_up.txt', RSRQ_2_1, fmt='%d', delimiter=',')
np.savetxt('RSRQ_2_2_up.txt', RSRQ_2_2, fmt='%d', delimiter=',')



                        #elif n == 1 and car_data_next_train_id[k] != '-':
                        #    up_next_station = np.append(up_next_station, np.array([car_data_next_train_id[k]]))
                            #print(down_next_station)



                    #print(list_car_data_time.index(str(terminal_data_time[k])))
        #start_time = list_car_data_time.index(str(terminal_data_time[0]))

        #print(list_car_data_time.index(str(terminal_data_time[0])))
        #print(type(car_data_time))
        #index = car_data_time.find(str(terminal_data_time[0]))
        #print(index)
        #print(terminal_data_RSRP_1_1[0]+1)


#df_data = df['Time']
#df_data2 = df2['Time']
#print(df_data[34537])
#print(str(df_data2[0]))

#if df_data[34537] == str(df_data2[0]):
#    print('Hello')

print("time :", time.time() - start)

#writer = pd.ExcelWriter('test1.xlsx', engine = 'xlsxwriter')
#df.to_excel(writer)
#writer.close()

